<?php include 'header.php'; ?>

                     <h1>歡迎使用後台管理系統</h1>

<?php include 'footer.php'; ?>